# Name:  Last, First
# netID: Insert your netID here

# I worked with the following classmates on this assignment:
# 1) Name: Last, First
# 2) Name: Last, First

######################################################################
# Place your solutions here
######################################################################

integerSquareRoot <- function(x) {
    return(42)
}

fabricYards <- function(inches) {
    return(42)
}

fabricExcess <- function(inches) {
    return(42)
}

isPerfectCube <- function(x) {
    return(42)
}

kthDigit <- function(x, k) {
    return(42)
}

numberOfPoolBalls <- function(rows) {
    return(42)
}

#--------------------------------------------------------------
# ignore_rest
# This comment is for the autograder - it will ignore all code below here

library(TurtleGraphics)

turtleSquare <- function(s) {
    return(42)
}

# Run these lines to test the turtle graphics output
turtle_init()
turtleSquare(50)

# Bonus Credit (Optional):

turtleTriangle <- function(s) {
    return(42)
}

# Run these lines to test the turtle graphics output
turtle_init()
turtleTriangle(50)
